"use strict";

/*
 * Copyright OpenSearch Contributors
 * SPDX-License-Identifier: Apache-2.0
 */
module.exports = {
  rootDir: '../',
  setupFiles: ['<rootDir>/test/polyfills.ts', '<rootDir>/test/setupTests.ts'],
  setupFilesAfterEnv: ['<rootDir>/test/setup.jest.ts'],
  roots: ['<rootDir>'],
  coverageDirectory: './coverage',
  moduleNameMapper: {
    '\\.(css|less|scss)$': '<rootDir>/test/mocks/styleMock.ts',
    '^ui/(.*)': '<rootDir>/../../src/legacy/ui/public/$1/'
  },
  coverageReporters: ['lcov', 'text', 'cobertura'],
  testMatch: ['**/*.test.js', '**/*.test.jsx', '**/*.test.ts', '**/*.test.tsx'],
  collectCoverageFrom: ['**/*.ts', '**/*.tsx', '**/*.js', '**/*.jsx', '!**/models/**', '!**/node_modules/**', '!**/index.ts', '!<rootDir>/index.js', '!<rootDir>/public/app.js', '!<rootDir>/public/temporary/**', '!<rootDir>/babel.config.js', '!<rootDir>/test/**', '!<rootDir>/server/**', '!<rootDir>/coverage/**', '!<rootDir>/scripts/**', '!<rootDir>/build/**', '!<rootDir>/cypress/**', '!**/vendor/**'],
  clearMocks: true,
  testPathIgnorePatterns: ['<rootDir>/build/', '<rootDir>/node_modules/'],
  modulePathIgnorePatterns: ['securityAnalyticsDashboards'],
  testEnvironment: 'jsdom'
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImplc3QuY29uZmlnLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydHMiLCJyb290RGlyIiwic2V0dXBGaWxlcyIsInNldHVwRmlsZXNBZnRlckVudiIsInJvb3RzIiwiY292ZXJhZ2VEaXJlY3RvcnkiLCJtb2R1bGVOYW1lTWFwcGVyIiwiY292ZXJhZ2VSZXBvcnRlcnMiLCJ0ZXN0TWF0Y2giLCJjb2xsZWN0Q292ZXJhZ2VGcm9tIiwiY2xlYXJNb2NrcyIsInRlc3RQYXRoSWdub3JlUGF0dGVybnMiLCJtb2R1bGVQYXRoSWdub3JlUGF0dGVybnMiLCJ0ZXN0RW52aXJvbm1lbnQiXSwibWFwcGluZ3MiOiI7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2ZDLEVBQUFBLE9BQU8sRUFBRSxLQURNO0FBRWZDLEVBQUFBLFVBQVUsRUFBRSxDQUFDLDZCQUFELEVBQWdDLDhCQUFoQyxDQUZHO0FBR2ZDLEVBQUFBLGtCQUFrQixFQUFFLENBQUMsOEJBQUQsQ0FITDtBQUlmQyxFQUFBQSxLQUFLLEVBQUUsQ0FBQyxXQUFELENBSlE7QUFLZkMsRUFBQUEsaUJBQWlCLEVBQUUsWUFMSjtBQU1mQyxFQUFBQSxnQkFBZ0IsRUFBRTtBQUNoQiwyQkFBdUIsbUNBRFA7QUFFaEIsZ0JBQVk7QUFGSSxHQU5IO0FBVWZDLEVBQUFBLGlCQUFpQixFQUFFLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsV0FBakIsQ0FWSjtBQVdmQyxFQUFBQSxTQUFTLEVBQUUsQ0FBQyxjQUFELEVBQWlCLGVBQWpCLEVBQWtDLGNBQWxDLEVBQWtELGVBQWxELENBWEk7QUFZZkMsRUFBQUEsbUJBQW1CLEVBQUUsQ0FDbkIsU0FEbUIsRUFFbkIsVUFGbUIsRUFHbkIsU0FIbUIsRUFJbkIsVUFKbUIsRUFLbkIsZUFMbUIsRUFNbkIscUJBTm1CLEVBT25CLGNBUG1CLEVBUW5CLHFCQVJtQixFQVNuQiwwQkFUbUIsRUFVbkIsZ0NBVm1CLEVBV25CLDRCQVhtQixFQVluQixvQkFabUIsRUFhbkIsc0JBYm1CLEVBY25CLHdCQWRtQixFQWVuQix1QkFmbUIsRUFnQm5CLHFCQWhCbUIsRUFpQm5CLHVCQWpCbUIsRUFrQm5CLGVBbEJtQixDQVpOO0FBZ0NmQyxFQUFBQSxVQUFVLEVBQUUsSUFoQ0c7QUFpQ2ZDLEVBQUFBLHNCQUFzQixFQUFFLENBQUMsa0JBQUQsRUFBcUIseUJBQXJCLENBakNUO0FBa0NmQyxFQUFBQSx3QkFBd0IsRUFBRSxDQUFDLDZCQUFELENBbENYO0FBbUNmQyxFQUFBQSxlQUFlLEVBQUU7QUFuQ0YsQ0FBakIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQ29weXJpZ2h0IE9wZW5TZWFyY2ggQ29udHJpYnV0b3JzXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICByb290RGlyOiAnLi4vJyxcbiAgc2V0dXBGaWxlczogWyc8cm9vdERpcj4vdGVzdC9wb2x5ZmlsbHMudHMnLCAnPHJvb3REaXI+L3Rlc3Qvc2V0dXBUZXN0cy50cyddLFxuICBzZXR1cEZpbGVzQWZ0ZXJFbnY6IFsnPHJvb3REaXI+L3Rlc3Qvc2V0dXAuamVzdC50cyddLFxuICByb290czogWyc8cm9vdERpcj4nXSxcbiAgY292ZXJhZ2VEaXJlY3Rvcnk6ICcuL2NvdmVyYWdlJyxcbiAgbW9kdWxlTmFtZU1hcHBlcjoge1xuICAgICdcXFxcLihjc3N8bGVzc3xzY3NzKSQnOiAnPHJvb3REaXI+L3Rlc3QvbW9ja3Mvc3R5bGVNb2NrLnRzJyxcbiAgICAnXnVpLyguKiknOiAnPHJvb3REaXI+Ly4uLy4uL3NyYy9sZWdhY3kvdWkvcHVibGljLyQxLycsXG4gIH0sXG4gIGNvdmVyYWdlUmVwb3J0ZXJzOiBbJ2xjb3YnLCAndGV4dCcsICdjb2JlcnR1cmEnXSxcbiAgdGVzdE1hdGNoOiBbJyoqLyoudGVzdC5qcycsICcqKi8qLnRlc3QuanN4JywgJyoqLyoudGVzdC50cycsICcqKi8qLnRlc3QudHN4J10sXG4gIGNvbGxlY3RDb3ZlcmFnZUZyb206IFtcbiAgICAnKiovKi50cycsXG4gICAgJyoqLyoudHN4JyxcbiAgICAnKiovKi5qcycsXG4gICAgJyoqLyouanN4JyxcbiAgICAnISoqL21vZGVscy8qKicsXG4gICAgJyEqKi9ub2RlX21vZHVsZXMvKionLFxuICAgICchKiovaW5kZXgudHMnLFxuICAgICchPHJvb3REaXI+L2luZGV4LmpzJyxcbiAgICAnITxyb290RGlyPi9wdWJsaWMvYXBwLmpzJyxcbiAgICAnITxyb290RGlyPi9wdWJsaWMvdGVtcG9yYXJ5LyoqJyxcbiAgICAnITxyb290RGlyPi9iYWJlbC5jb25maWcuanMnLFxuICAgICchPHJvb3REaXI+L3Rlc3QvKionLFxuICAgICchPHJvb3REaXI+L3NlcnZlci8qKicsXG4gICAgJyE8cm9vdERpcj4vY292ZXJhZ2UvKionLFxuICAgICchPHJvb3REaXI+L3NjcmlwdHMvKionLFxuICAgICchPHJvb3REaXI+L2J1aWxkLyoqJyxcbiAgICAnITxyb290RGlyPi9jeXByZXNzLyoqJyxcbiAgICAnISoqL3ZlbmRvci8qKicsXG4gIF0sXG4gIGNsZWFyTW9ja3M6IHRydWUsXG4gIHRlc3RQYXRoSWdub3JlUGF0dGVybnM6IFsnPHJvb3REaXI+L2J1aWxkLycsICc8cm9vdERpcj4vbm9kZV9tb2R1bGVzLyddLFxuICBtb2R1bGVQYXRoSWdub3JlUGF0dGVybnM6IFsnc2VjdXJpdHlBbmFseXRpY3NEYXNoYm9hcmRzJ10sXG4gIHRlc3RFbnZpcm9ubWVudDogJ2pzZG9tJyxcbn07XG4iXX0=